const xlsx = require('xlsx')
const { getSheet } = require('../../cache/excelCache')

// ⏱️ Helper para no saturar WhatsApp con muchos mensajes seguidos
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// 📋 Construye el texto del aviso
function buildAvisoText(u, tipo, puntos, debeActual, bloqueDeudas, total) {
  return `📢 *Aviso de Cacería* 📢

👋 ¡Hola, *${u.Nombre}*! 👋

⚠️ Tu *status* esta semana fue: ❌ *NO CUMPLIÓ*

🎯 *Tipo de Caza:* ${tipo}
🎯 *Total de Caza Semanal:* ${u['Total Semanal'] ?? 0} Mobs
🧮 *Total de Puntos:* ${puntos} Puntos

📊 *Detalle de mobs realizados:*
🔹 *L1*: ${u.Mob1 ?? 0} Mobs 🐰
🔹 *L2*: ${u.Mob2 ?? 0} Mobs 🐺
🔹 *L3*: ${u.Mob3 ?? 0} Mobs 🐲
🔹 *L4*: ${u.Mob4 ?? 0} Mobs 🐧
🔹 *L5*: ${u.Mob5 ?? 0} Mobs 🐯

❌ Esta semana quedaste debiendo *${debeActual} puntos*.

${bloqueDeudas}

📌 Recuerda que debes cumplir la meta semanal más tu deuda acumulada.

🎯 *Total a cumplir esta semana: ${total} puntos.*

🅣🅗 - 🅑🅞🅣`
}

module.exports = {
  name: 'avisos',
  admin: true,

  async execute(sock, msg) {
    const chatId = msg.key.remoteJid
    const META_SEMANAL = 35

    try {
      await sock.sendMessage(chatId, { text: '📢 Enviando avisos...' })

      // ── Cargar hoja ──────────────────────────────────────────────
      const sheet = getSheet('Avisos')
      if (!sheet) {
        await sock.sendMessage(chatId, {
          text: '⚠️ No se encontró la hoja *"Avisos"* en el Excel.',
        })
        return
      }

      const data = xlsx.utils.sheet_to_json(sheet)
      if (!data.length) {
        await sock.sendMessage(chatId, {
          text: '⚠️ No hay registros en la hoja *"Avisos"*.',
        })
        return
      }

      // ── Detectar columnas de historial ───────────────────────────
      const headers = Object.keys(data[0])
      const indexSemanaAnterior = headers.indexOf('Semana anterior')
      const columnasHistorial =
        indexSemanaAnterior !== -1 ? headers.slice(indexSemanaAnterior + 1) : []

      // ── Enviar avisos ────────────────────────────────────────────
      let enviados = 0
      let errores = 0

      for (const u of data) {
        if (!u.Numero) continue

        try {
          // Determinar tipo y puntos
          const cuota = String(u['Cuota Diaria'] ?? '').toLowerCase()
          let tipo = 'General'
          let puntos = 0

          if (cuota.includes('5lvl2')) {
            tipo = 'Nivel 2'
            puntos = u['Puntos Nvl 2'] ?? 0
          } else if (cuota.includes('5lvl1')) {
            tipo = 'Nivel 1'
            puntos = u['Puntos Nvl 1'] ?? 0
          }

          // Calcular deuda total y construir historial
          const debeActual = Number(u.Debe) ?? 0
          let historialDeuda = ''
          let deudaAnteriorTotal = 0

          for (const col of columnasHistorial) {
            const valor = Number(u[col]) || 0
            if (valor > 0) {
              historialDeuda += `📂 ${col}: ${valor} puntos\n`
              deudaAnteriorTotal += valor
            }
          }

          const bloqueDeudas =
            deudaAnteriorTotal > 0
              ? `📜 *Deudas anteriores:*\n${historialDeuda.trimEnd()}`
              : `📜 *Deudas anteriores:* Ninguna`

          const total = META_SEMANAL + debeActual + deudaAnteriorTotal
          const texto = buildAvisoText(u, tipo, puntos, debeActual, bloqueDeudas, total)

          // ✅ Envío con pequeña pausa para evitar ban por spam
          await sock.sendMessage(`${u.Numero}@c.us`, { text: texto })
          enviados++

          await sleep(1500) // 👈 1.5s entre mensajes — ajusta según tu necesidad

        } catch (innerError) {
          errores++
          console.error(`❌ Error enviando aviso a ${u.Numero}:`, innerError)
        }
      }

      // ── Reporte final ────────────────────────────────────────────
      await sock.sendMessage(chatId, {
        text: `✅ *Avisos enviados:* ${enviados}\n${errores > 0 ? `⚠️ *Errores:* ${errores}` : ''}`.trim(),
      })

    } catch (error) {
      console.error('❌ Error en comando /avisos:', error)
      await sock.sendMessage(chatId, {
        text: '⚠️ Ocurrió un error al enviar los avisos.',
      })
    }
  },
}