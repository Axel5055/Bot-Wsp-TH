const xlsx = require('xlsx')
const { getSheet } = require('../../cache/excelCache')
const { getConfig } = require('../../config/fdgConfig')

module.exports = {
  name: 'fdgtop',
  admin: false,

  async execute(sock, msg) {

    const chatId = msg.key.remoteJid

    try {

      const sheet = getSheet('FDG')

      if (!sheet) {
        await sock.sendMessage(chatId, {
          text: '*⚠️ No se encontró la hoja FDG.*',
        })
        return
      }

      const data = xlsx.utils.sheet_to_json(sheet)

      // 📥 Obtener configuración de premios
      const config = getConfig()
      const premios = config.premios || {}

      const top3 = data
        .sort((a, b) => (Number(b['Puntos']) || 0) - (Number(a['Puntos']) || 0))
        .slice(0, 3)

      const medals = ['🥇','🥈','🥉']

      let txt = `🏆 *TOP 3 FDG (Fiesta de Gremio)* 🏆\n\n`

      top3.forEach((p, i) => {

        const nombre = p['Nombre'] || 'Jugador'
        const puntos = Number(p['Puntos']) || 0
        const misiones = `${p['Misiones completadas'] || 0}/${p['Misiones tomadas'] || 0}`

        const premio = premios[i + 1] || 'Sin premio definido'

        txt += `${medals[i]} *${nombre}*\n`
        txt += `📜 Misiones: ${misiones}\n`
        txt += `⭐ Puntos: ${puntos}\n`
        txt += `🎁 Premio: *${premio}*\n\n`

      })

      txt += `🔥 ¡Los mejores jugadores del evento!`

      await sock.sendMessage(chatId, { text: txt })

    } catch (error) {

      console.error(error)

      await sock.sendMessage(chatId, {
        text: '⚠️ Error ejecutando fdgtop.',
      })

    }

  },
}