const xlsx = require('xlsx')
const moment = require('moment-timezone')
const { getSheet } = require('../../cache/excelCache')
const { getConfig } = require('../../config/fdgConfig')

module.exports = {
  name: 'fdgresumen',
  keywords: ['generales de fdg'],
  admin: false,

  async execute(sock, msg) {

    const chatId = msg.key.remoteJid

    try {

      const sheet = getSheet('FDG')

      if (!sheet) {
        await sock.sendMessage(chatId, {
          text: '*⚠️ No se encontró la hoja FDG.*',
        })
        return
      }

      const data = xlsx.utils.sheet_to_json(sheet)

      // 📥 Configuración desde JSON
      const config = getConfig()
      const puntajeMinimo = Number(config.puntajeMinimo) || 0

      const totalJugadores = data.length

      let cumplieron = 0
      let noCumplieron = 0
      let totalPuntos = 0

      data.forEach(p => {

        const puntos = Number(p['Puntos']) || 0
        totalPuntos += puntos

        if (puntos >= puntajeMinimo) {
          cumplieron++
        } else {
          noCumplieron++
        }

      })

      // 📊 porcentaje de cumplimiento
      const porcentaje = totalJugadores > 0
        ? ((cumplieron / totalJugadores) * 100).toFixed(1)
        : 0

      // 📊 barra visual
      const barraLength = 10
      const llenos = Math.round((porcentaje / 100) * barraLength)
      const vacios = barraLength - llenos
      const barra = '█'.repeat(llenos) + '░'.repeat(vacios)

      let txt = `🎉 *ESTADÍSTICAS FDG* 🎉\n\n`

      txt += `🎯 Puntaje mínimo: *${puntajeMinimo}*\n`
      txt += `👥 Jugadores: *${totalJugadores}*\n\n`

      txt += `✅ Cumplieron: *${cumplieron}*\n`
      txt += `❌ No cumplieron: *${noCumplieron}*\n\n`

      txt += `⭐ Puntos totales: *${totalPuntos}*\n\n`

      txt += `📊 *Cumplimiento FDG*\n`
      txt += `${barra} *${porcentaje}%*\n\n`

      txt += `📅 ${moment().tz('America/Mexico_City').format('DD/MM/YYYY')}\n\n`
      txt += `🅣🅗 — 🅑🅞🅣`

      await sock.sendMessage(chatId, { text: txt })

    } catch (error) {

      console.error(error)

      await sock.sendMessage(chatId, {
        text: '⚠️ Error ejecutando fdgstats.',
      })

    }

  },
}