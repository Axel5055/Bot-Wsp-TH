const xlsx = require('xlsx')
const { getSheet } = require('../../cache/excelCache')
const { getConfig } = require('../../config/fdgConfig')

module.exports = {
  name: 'fdgstats',
  admin: false,

  async execute(sock, msg, args) {

    const chatId = msg.key.remoteJid

    try {

      const nombreBuscado = args.join(' ').toLowerCase()

      if (!nombreBuscado) {
        await sock.sendMessage(chatId, {
          text: '⚠️ Usa el comando así:\n\n#fdgstats Nombre'
        })
        return
      }

      const sheet = getSheet('FDG')

      if (!sheet) {
        await sock.sendMessage(chatId, {
          text: '*⚠️ No se encontró la hoja FDG.*'
        })
        return
      }

      const data = xlsx.utils.sheet_to_json(sheet)

      const config = getConfig()
      const puntajeMinimo = config.puntajeMinimo || 0

      const jugador = data.find(p =>
        String(p['Nombre'] || '').toLowerCase() === nombreBuscado
      )

      if (!jugador) {
        await sock.sendMessage(chatId, {
          text: `❌ No se encontró el jugador *${nombreBuscado}*`
        })
        return
      }

      const nombre = jugador['Nombre'] || 'Jugador'
      const puntos = Number(jugador['Puntos']) || 0
      const completadas = jugador['Misiones completadas'] || 0
      const tomadas = jugador['Misiones tomadas'] || 0
      const estado = puntos >= puntajeMinimo ? '✅ Cumplio' : '❌ No Cumplio'

      const progreso = Math.min(1, puntos / puntajeMinimo)

      const totalBar = 10
      const filled = Math.round(progreso * totalBar)
      const empty = totalBar - filled

      const barra = '🟩'.repeat(filled) + '⬜'.repeat(empty)

      const faltante = Math.max(0, puntajeMinimo - puntos)

      let txt = `📊 *STATS FDG*\n\n`

      txt += `👤 Jugador: *${nombre}*\n\n`

      txt += `⭐ Puntos: *${puntos}*\n`
      txt += `🎯 Meta: ${puntajeMinimo}\n`
      txt += `${barra}\n\n`

      txt += `📜 Misiones: ${completadas}/${tomadas}\n`
      txt += `📌 Estado: *${estado}*\n`

      if (puntos < puntajeMinimo) {
        txt += `⚠️ Faltan: *${faltante}* pts\n`
      } else {
        txt += `🔥 Meta cumplida\n`
      }

      await sock.sendMessage(chatId, { text: txt })

    } catch (error) {

      console.error(error)

      await sock.sendMessage(chatId, {
        text: '⚠️ Error ejecutando fdgstats.'
      })

    }

  },
}